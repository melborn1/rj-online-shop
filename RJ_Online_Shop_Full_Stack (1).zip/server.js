require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const JWT_SECRET = process.env.JWT_SECRET || 'local-development-only-change-me';
const ADMIN_EMAIL = (process.env.ADMIN_EMAIL || 'admin@rjshop.example').toLowerCase();
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'ChangeThisAdminPassword123!';
const COMMISSION_RATE = Math.min(1, Math.max(0, Number(process.env.AFFILIATE_COMMISSION_RATE || 0.4)));
const SHOP_NAME = process.env.SHOP_NAME || 'R&J Online Shop';

const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, {recursive:true});
const db = new Database(path.join(dataDir, 'rj-shop.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL, description TEXT DEFAULT '', price INTEGER NOT NULL, compare_price INTEGER DEFAULT 0, emoji TEXT DEFAULT '👟', stock INTEGER DEFAULT 20, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS affiliates (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL UNIQUE REFERENCES users(id), code TEXT UNIQUE NOT NULL, status TEXT DEFAULT 'pending', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS affiliate_clicks (id INTEGER PRIMARY KEY, affiliate_id INTEGER NOT NULL REFERENCES affiliates(id), ip_hash TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), affiliate_id INTEGER REFERENCES affiliates(id), status TEXT DEFAULT 'pending_payment', payment_status TEXT DEFAULT 'demo_pending', subtotal INTEGER NOT NULL, shipping INTEGER NOT NULL DEFAULT 0, total INTEGER NOT NULL, address TEXT NOT NULL, phone TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS order_items (id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id), product_id INTEGER NOT NULL REFERENCES products(id), name TEXT NOT NULL, price INTEGER NOT NULL, quantity INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS commissions (id INTEGER PRIMARY KEY, affiliate_id INTEGER NOT NULL REFERENCES affiliates(id), order_id INTEGER NOT NULL UNIQUE REFERENCES orders(id), amount INTEGER NOT NULL, status TEXT DEFAULT 'pending', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS payouts (id INTEGER PRIMARY KEY, affiliate_id INTEGER NOT NULL REFERENCES affiliates(id), amount INTEGER NOT NULL, method TEXT NOT NULL, account_details TEXT NOT NULL, status TEXT DEFAULT 'requested', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);
const productCount = db.prepare('SELECT COUNT(*) n FROM products').get().n;
if (!productCount) {
 const seed = [
  ['R&J Street Runner','Running','Lightweight everyday running shoes.',249900,329900,'👟',30],
  ['Cloud White Casual','Casual','Clean, versatile casual sneakers.',189900,249900,'🥾',25],
  ['Court High-Top','Basketball','Supportive high-top court style.',329900,399900,'👟',18],
  ['Everyday Lifestyle','Lifestyle','Comfort for daily wear.',219900,279900,'🤍',24],
  ['Classic Street Low','Casual','A timeless low-top silhouette.',169900,219900,'👞',30],
  ['LightStep Go Walk','Running','Soft cushioning for long walks.',149900,189900,'👟',20],
  ['Comfort Slides','Slides','Easy slip-on comfort.',59900,79900,'🩴',40],
  ['Redline Court Pro','Basketball','Bold court-inspired design.',289900,359900,'👟',15]
 ];
 const insert = db.prepare('INSERT INTO products (name,category,description,price,compare_price,emoji,stock) VALUES (?,?,?,?,?,?,?)');
 const tx = db.transaction(rows=>rows.forEach(r=>insert.run(...r)));
 tx(seed);
}
const appLimiter = rateLimit({windowMs:15*60*1000, limit:300, standardHeaders:true, legacyHeaders:false});
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:'100kb'}));
app.use(cookieParser());
app.use(appLimiter);
app.use(express.static(path.join(__dirname,'public')));

function signToken(user) { return jwt.sign({id:user.id,email:user.email,name:user.name,role:user.role||'customer'},JWT_SECRET,{expiresIn:'7d'}); }
function auth(req,res,next) {
 const token = (req.headers.authorization||'').replace(/^Bearer /,'') || req.cookies.rj_token;
 if(!token) return res.status(401).json({error:'Please sign in first.'});
 try { req.user=jwt.verify(token,JWT_SECRET); next(); } catch { return res.status(401).json({error:'Session expired. Please sign in again.'}); }
}
function admin(req,res,next) { auth(req,res,()=>req.user.role==='admin'?next():res.status(403).json({error:'Admin access required.'})); }
function cleanEmail(email){return String(email||'').trim().toLowerCase();}
function validEmail(email){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);}
function publicUser(u){return {id:u.id,name:u.name,email:u.email};}
function getAffiliateByCode(code){return db.prepare("SELECT a.*,u.name FROM affiliates a JOIN users u ON u.id=a.user_id WHERE a.code=? AND a.status='approved'").get(String(code||'').toUpperCase());}

app.get('/api/config',(req,res)=>res.json({shopName:SHOP_NAME,commissionRate:COMMISSION_RATE,paymentMode:process.env.PAYMENT_MODE||'demo'}));
app.get('/api/products',(req,res)=>res.json(db.prepare('SELECT id,name,category,description,price,compare_price AS comparePrice,emoji,stock FROM products WHERE active=1 ORDER BY id').all()));
app.post('/api/auth/register', async (req,res)=>{
 const name=String(req.body.name||'').trim(), email=cleanEmail(req.body.email), password=String(req.body.password||'');
 if(name.length<2||!validEmail(email)||password.length<8) return res.status(400).json({error:'Enter your name, a valid email, and a password with at least 8 characters.'});
 try { const hash=await bcrypt.hash(password,12); const result=db.prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)').run(name,email,hash); const user={id:result.lastInsertRowid,name,email}; res.json({token:signToken(user),user:publicUser(user)}); }
 catch(e){res.status(409).json({error:'That email may already be registered.'});}
});
app.post('/api/auth/login', async (req,res)=>{
 const email=cleanEmail(req.body.email), password=String(req.body.password||'');
 if(email===ADMIN_EMAIL && await bcrypt.compare(password, await bcrypt.hash(ADMIN_PASSWORD, 12)).catch(()=>false)) {
   // Admin credentials are compared directly below; this branch is intentionally not used.
 }
 if(email===ADMIN_EMAIL && password===ADMIN_PASSWORD) return res.json({token:jwt.sign({id:0,email,name:'R&J Admin',role:'admin'},JWT_SECRET,{expiresIn:'7d'}),user:{name:'R&J Admin',email,role:'admin'}});
 const u=db.prepare('SELECT * FROM users WHERE email=?').get(email);
 if(!u || !(await bcrypt.compare(password,u.password_hash))) return res.status(401).json({error:'Incorrect email or password.'});
 res.json({token:signToken(u),user:publicUser(u)});
});
app.get('/api/me',auth,(req,res)=>res.json({user:req.user}));

app.post('/api/affiliate/apply',auth,(req,res)=>{
 const existing=db.prepare('SELECT * FROM affiliates WHERE user_id=?').get(req.user.id);
 if(existing) return res.json({status:existing.status,code:existing.code});
 const code=(req.user.name.replace(/[^a-z0-9]/gi,'').slice(0,7)+crypto.randomBytes(2).toString('hex')).toUpperCase();
 db.prepare('INSERT INTO affiliates(user_id,code,status) VALUES(?,?,?)').run(req.user.id,code,'pending');
 res.json({status:'pending',code,message:'Application received. An admin must approve it before referral tracking is enabled.'});
});
app.get('/api/affiliate/me',auth,(req,res)=>{
 const a=db.prepare('SELECT * FROM affiliates WHERE user_id=?').get(req.user.id);
 if(!a) return res.json({affiliate:null});
 const clicks=db.prepare('SELECT COUNT(*) n FROM affiliate_clicks WHERE affiliate_id=?').get(a.id).n;
 const sales=db.prepare('SELECT COUNT(*) n FROM orders WHERE affiliate_id=? AND payment_status="paid"').get(a.id).n;
 const earnings=db.prepare('SELECT COALESCE(SUM(amount),0) n FROM commissions WHERE affiliate_id=?').get(a.id).n;
 const pending=db.prepare('SELECT COALESCE(SUM(amount),0) n FROM commissions WHERE affiliate_id=? AND status="pending"').get(a.id).n;
 const paid=db.prepare('SELECT COALESCE(SUM(amount),0) n FROM commissions WHERE affiliate_id=? AND status="paid"').get(a.id).n;
 res.json({affiliate:a,clicks,sales,earnings,pending,paid,commissionRate:COMMISSION_RATE});
});
app.post('/api/affiliate/payout',auth,(req,res)=>{
 const a=db.prepare("SELECT * FROM affiliates WHERE user_id=? AND status='approved'").get(req.user.id);
 if(!a) return res.status(400).json({error:'Your affiliate account must be approved first.'});
 const amount=Math.floor(Number(req.body.amount)), method=String(req.body.method||'').trim(), details=String(req.body.accountDetails||'').trim();
 const balance=db.prepare("SELECT COALESCE(SUM(amount),0) n FROM commissions WHERE affiliate_id=? AND status='pending'").get(a.id).n;
 if(!Number.isInteger(amount)||amount<10000||amount>balance||!method||details.length<4) return res.status(400).json({error:'Enter a valid payout amount (minimum ₱100), payout method, and account details; amount cannot exceed your pending balance.'});
 db.prepare('INSERT INTO payouts(affiliate_id,amount,method,account_details) VALUES(?,?,?,?)').run(a.id,amount,method,details);
 res.json({message:'Payout request submitted for admin review.'});
});

app.get('/r/:code',(req,res)=>{
 const a=getAffiliateByCode(req.params.code);
 if(a){
   const ip=crypto.createHash('sha256').update(String(req.ip)+'rj-demo-salt').digest('hex');
   db.prepare('INSERT INTO affiliate_clicks(affiliate_id,ip_hash) VALUES(?,?)').run(a.id,ip);
   res.cookie('rj_ref',a.code,{maxAge:30*24*60*60*1000,httpOnly:true,sameSite:'lax',secure:process.env.NODE_ENV==='production'});
 }
 res.redirect('/');
});

app.post('/api/orders',auth,(req,res)=>{
 const items=Array.isArray(req.body.items)?req.body.items:[], address=String(req.body.address||'').trim(), phone=String(req.body.phone||'').trim();
 if(!items.length||items.length>40||address.length<8||phone.length<6) return res.status(400).json({error:'Add items and enter a complete shipping address and phone number.'});
 let subtotal=0, normalized=[];
 for(const item of items){
   const id=Number(item.productId), quantity=Math.floor(Number(item.quantity));
   if(!Number.isInteger(id)||!Number.isInteger(quantity)||quantity<1||quantity>20) return res.status(400).json({error:'Invalid cart item.'});
   const p=db.prepare('SELECT * FROM products WHERE id=? AND active=1').get(id);
   if(!p||p.stock<quantity) return res.status(400).json({error:`${p?p.name:'A product'} is unavailable in the requested quantity.`});
   subtotal+=p.price*quantity; normalized.push({p,quantity});
 }
 const shipping=subtotal>=100000?0:9900, total=subtotal+shipping;
 const refCode=req.cookies.rj_ref||req.body.referralCode||'';
 const affiliate=getAffiliateByCode(refCode);
 const create=db.transaction(()=>{
   const o=db.prepare('INSERT INTO orders(user_id,affiliate_id,subtotal,shipping,total,address,phone) VALUES(?,?,?,?,?,?,?)').run(req.user.id,affiliate?affiliate.id:null,subtotal,shipping,total,address,phone);
   const ins=db.prepare('INSERT INTO order_items(order_id,product_id,name,price,quantity) VALUES(?,?,?,?,?)');
   const stock=db.prepare('UPDATE products SET stock=stock-? WHERE id=?');
   normalized.forEach(({p,quantity})=>{ins.run(o.lastInsertRowid,p.id,p.name,p.price,quantity);stock.run(quantity,p.id);});
   return o.lastInsertRowid;
 });
 const orderId=create();
 res.json({orderId,orderNumber:'RJ-'+String(orderId).padStart(6,'0'),subtotal,shipping,total,paymentStatus:'demo_pending',message:'Order created in demo mode. No payment has been collected.'});
});
app.get('/api/orders',auth,(req,res)=>{
 const orders=db.prepare('SELECT id,status,payment_status AS paymentStatus,subtotal,shipping,total,address,created_at AS createdAt FROM orders WHERE user_id=? ORDER BY id DESC').all(req.user.id);
 res.json(orders.map(o=>({...o,orderNumber:'RJ-'+String(o.id).padStart(6,'0'),items:db.prepare('SELECT name,price,quantity FROM order_items WHERE order_id=?').all(o.id)})));
});
app.get('/api/orders/track/:orderNumber',auth,(req,res)=>{
 const id=Number(String(req.params.orderNumber).replace(/^RJ-/i,''));
 const o=db.prepare('SELECT id,user_id,status,payment_status AS paymentStatus,subtotal,shipping,total,created_at AS createdAt FROM orders WHERE id=? AND user_id=?').get(id,req.user.id);
 if(!o) return res.status(404).json({error:'Order not found for this account.'});
 res.json({...o,orderNumber:'RJ-'+String(o.id).padStart(6,'0'),items:db.prepare('SELECT name,price,quantity FROM order_items WHERE order_id=?').all(o.id)});
});

app.get('/api/admin/summary',admin,(req,res)=>{
 const products=db.prepare('SELECT COUNT(*) n FROM products WHERE active=1').get().n;
 const orders=db.prepare('SELECT COUNT(*) n FROM orders').get().n;
 const paidRevenue=db.prepare("SELECT COALESCE(SUM(total),0) n FROM orders WHERE payment_status='paid'").get().n;
 const pendingOrders=db.prepare("SELECT COUNT(*) n FROM orders WHERE payment_status!='paid'").get().n;
 const affiliates=db.prepare("SELECT COUNT(*) n FROM affiliates WHERE status='pending'").get().n;
 const payoutRequests=db.prepare("SELECT COUNT(*) n FROM payouts WHERE status='requested'").get().n;
 res.json({products,orders,paidRevenue,pendingOrders,pendingAffiliateApplications:affiliates,payoutRequests});
});
app.get('/api/admin/orders',admin,(req,res)=>res.json(db.prepare(`SELECT o.id,o.status,o.payment_status AS paymentStatus,o.subtotal,o.shipping,o.total,o.address,o.phone,o.created_at AS createdAt,u.name AS customer,u.email,a.code AS affiliateCode FROM orders o JOIN users u ON u.id=o.user_id LEFT JOIN affiliates a ON a.id=o.affiliate_id ORDER BY o.id DESC LIMIT 200`).all().map(o=>({...o,orderNumber:'RJ-'+String(o.id).padStart(6,'0'),items:db.prepare('SELECT name,price,quantity FROM order_items WHERE order_id=?').all(o.id)}))));
app.post('/api/admin/orders/:id/mark-paid',admin,(req,res)=>{
 const id=Number(req.params.id), o=db.prepare('SELECT * FROM orders WHERE id=?').get(id);
 if(!o)return res.status(404).json({error:'Order not found.'});
 if(o.payment_status==='paid')return res.json({message:'Order is already marked paid.'});
 const tx=db.transaction(()=>{
   db.prepare("UPDATE orders SET payment_status='paid',status='processing' WHERE id=?").run(id);
   if(o.affiliate_id){
     const amount=Math.round(o.subtotal*COMMISSION_RATE);
     db.prepare('INSERT OR IGNORE INTO commissions(affiliate_id,order_id,amount,status) VALUES(?,?,?,?)').run(o.affiliate_id,id,amount,'pending');
   }
 });
 tx();res.json({message:'Order marked paid in admin demo; affiliate commission ledger updated if applicable.'});
});
app.get('/api/admin/affiliates',admin,(req,res)=>res.json(db.prepare(`SELECT a.id,a.code,a.status,a.created_at AS createdAt,u.name,u.email,(SELECT COUNT(*) FROM affiliate_clicks c WHERE c.affiliate_id=a.id) AS clicks,(SELECT COUNT(*) FROM orders o WHERE o.affiliate_id=a.id AND o.payment_status='paid') AS sales,(SELECT COALESCE(SUM(amount),0) FROM commissions cm WHERE cm.affiliate_id=a.id) AS earnings FROM affiliates a JOIN users u ON u.id=a.user_id ORDER BY a.id DESC`).all()));
app.post('/api/admin/affiliates/:id/approve',admin,(req,res)=>{const r=db.prepare("UPDATE affiliates SET status='approved' WHERE id=?").run(Number(req.params.id));if(!r.changes)return res.status(404).json({error:'Affiliate not found.'});res.json({message:'Affiliate approved.'});});
app.post('/api/admin/affiliates/:id/reject',admin,(req,res)=>{const r=db.prepare("UPDATE affiliates SET status='rejected' WHERE id=?").run(Number(req.params.id));if(!r.changes)return res.status(404).json({error:'Affiliate not found.'});res.json({message:'Affiliate application rejected.'});});
app.get('/api/admin/payouts',admin,(req,res)=>res.json(db.prepare(`SELECT p.id,p.amount,p.method,p.account_details AS accountDetails,p.status,p.created_at AS createdAt,a.code,u.name,u.email FROM payouts p JOIN affiliates a ON a.id=p.affiliate_id JOIN users u ON u.id=a.user_id ORDER BY p.id DESC`).all()));
app.post('/api/admin/payouts/:id/paid',admin,(req,res)=>{
 const p=db.prepare("SELECT * FROM payouts WHERE id=? AND status='requested'").get(Number(req.params.id));
 if(!p)return res.status(404).json({error:'Pending payout request not found.'});
 const tx=db.transaction(()=>{db.prepare("UPDATE payouts SET status='paid' WHERE id=?").run(p.id);let remaining=p.amount;const commissions=db.prepare("SELECT id,amount FROM commissions WHERE affiliate_id=? AND status='pending' ORDER BY id").all(p.affiliate_id);for(const c of commissions){if(remaining<=0)break;if(c.amount<=remaining){db.prepare("UPDATE commissions SET status='paid' WHERE id=?").run(c.id);remaining-=c.amount;}else{db.prepare("UPDATE commissions SET amount=amount-? WHERE id=?").run(remaining,c.id);db.prepare("INSERT INTO commissions(affiliate_id,order_id,amount,status) VALUES(?,?,?,'paid')").run(p.affiliate_id,c.order_id,remaining);remaining=0;}}});
 tx();res.json({message:'Payout marked paid in the ledger. Complete the actual bank/e-wallet transfer separately.'});
});
app.get('/api/admin/products',admin,(req,res)=>res.json(db.prepare('SELECT * FROM products ORDER BY id').all()));
app.post('/api/admin/products',admin,(req,res)=>{
 const {name,category,description='',price,comparePrice=0,emoji='👟',stock=0}=req.body;
 if(!String(name||'').trim()||!String(category||'').trim()||!Number.isInteger(Number(price))||Number(price)<1||!Number.isInteger(Number(stock))||Number(stock)<0)return res.status(400).json({error:'Enter valid product details. Prices are in centavos (e.g. ₱2499 = 249900).'});
 const r=db.prepare('INSERT INTO products(name,category,description,price,compare_price,emoji,stock) VALUES(?,?,?,?,?,?,?)').run(name,category,description,Number(price),Number(comparePrice)||0,emoji,Number(stock));
 res.json({id:r.lastInsertRowid,message:'Product added.'});
});
app.patch('/api/admin/products/:id',admin,(req,res)=>{
 const p=db.prepare('SELECT * FROM products WHERE id=?').get(Number(req.params.id));if(!p)return res.status(404).json({error:'Product not found.'});
 const price=req.body.price===undefined?p.price:Number(req.body.price),stock=req.body.stock===undefined?p.stock:Number(req.body.stock);
 if(!Number.isInteger(price)||price<1||!Number.isInteger(stock)||stock<0)return res.status(400).json({error:'Invalid price or stock.'});
 db.prepare('UPDATE products SET name=?,category=?,description=?,price=?,compare_price=?,emoji=?,stock=?,active=? WHERE id=?').run(req.body.name??p.name,req.body.category??p.category,req.body.description??p.description,price,req.body.comparePrice===undefined?p.compare_price:Number(req.body.comparePrice),req.body.emoji??p.emoji,stock,req.body.active===undefined?p.active:(req.body.active?1:0),p.id);
 res.json({message:'Product updated.'});
});
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`${SHOP_NAME} running at http://localhost:${PORT}`));
