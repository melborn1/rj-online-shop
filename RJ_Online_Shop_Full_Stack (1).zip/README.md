# R&J Online Shop — full-stack starter

This project includes an Express backend, SQLite database, responsive shop UI, product search/categories, cart, customer registration/login, demo checkout, order history/tracking, affiliate applications, referral codes, click tracking, 40% commission ledger, payout requests, and an admin dashboard.

## Run locally
1. Install Node.js 20 or newer.
2. Extract the ZIP and open a terminal in this folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env` and change `JWT_SECRET` and `ADMIN_PASSWORD`.
5. Run `npm start`.
6. Visit `http://localhost:3000`.

The database is created automatically in `data/rj-shop.sqlite`. Demo products are seeded on first run.

## Demo admin
Use the values in `.env` (`ADMIN_EMAIL` and `ADMIN_PASSWORD`) on the Admin page. Change the default password before deployment.

## Important: demo checkout vs real money
Checkout in this starter creates an order marked **Pending payment / Demo checkout**. It does NOT charge a card, GCash, or Maya. To accept live payments, connect a payment provider such as PayMongo or Stripe, verify signed webhooks server-side, and only mark orders paid after provider confirmation. Never put secret API keys in browser code.

## Affiliate rules
The demo uses a 40% commission rate on product subtotal for orders placed through a referral code. Commission entries are created only when an admin marks an order paid. The rate is configurable via `AFFILIATE_COMMISSION_RATE`; have your actual affiliate terms, refunds/chargebacks, taxes, payout minimums, and applicable Philippine consumer/privacy requirements reviewed before launch.

## Production checklist
- Deploy to a Node host with persistent disk or migrate SQLite to a managed database.
- Set strong environment secrets and HTTPS.
- Connect real payment provider and webhook verification.
- Configure email verification, password reset, transactional emails, shipping/carrier integration, stock controls, refunds, and backups.
- Add privacy policy, terms, return/shipping policy, and affiliate agreement.
- Review security, data privacy, taxes, and legal obligations before taking real orders.

This is a usable development foundation, not a fully deployed live business. Do not use real customer data until production security and payment integrations have been completed.
